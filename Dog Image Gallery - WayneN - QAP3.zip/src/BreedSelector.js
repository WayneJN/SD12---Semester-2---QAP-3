import React, { useState, useEffect } from 'react';
import dogSearchButton from './Images/dogsearchbutton.png'; // Correct import statement for the image
import './shared.css'; // Import the shared CSS file for common styles
import './BreedSelector.css'; // Import the specific CSS file for the BreedSelector component

const BreedSelector = ({ setBreed, setNumImages, setImages }) => {
  const [breeds, setBreeds] = useState([]);
  const [selectedBreed, setSelectedBreed] = useState('');
  const [imageCount, setImageCount] = useState(1);

  useEffect(() => {
    fetch('https://dog.ceo/api/breeds/list/all')
      .then(response => response.json())
      .then(data => setBreeds(Object.keys(data.message)));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setBreed(selectedBreed);
    setNumImages(imageCount);
    const response = await fetch(`https://dog.ceo/api/breed/${selectedBreed}/images/random/${imageCount}`);
    const data = await response.json();
    setImages(data.message);
  };

  return (
    <div className="form-container"> {/* New container */}
      <form onSubmit={handleSubmit} className="breed-selector-form">
        <label htmlFor="breedSelect">Select Breed:</label>
        <select id="breedSelect" className="select-box" value={selectedBreed} onChange={e => setSelectedBreed(e.target.value)}>
          {breeds.map(breed => (
            <option key={breed} value={breed}>{breed}</option>
          ))}
        </select>
        <label htmlFor="imageCount">Number of Images:</label>
        <input 
          type="number" 
          id="imageCount"
          className="number-input"
          value={imageCount} 
          onChange={e => setImageCount(Math.min(Math.max(e.target.value, 0), 100))} 
          min="0" max="100"
        />
        <button type="submit" className="search-button">
          <img src={dogSearchButton} alt="Fetch Images" style={{ width: '100px', height: 'auto', cursor: 'pointer' }} />
        </button>
      </form>
    </div>
  );
};

export default BreedSelector;
