// Dog Image ImageGallery
// QAP3
// Submitted by : Wayne Norman
// Date : Nov 30th, 2024




import React, { useState } from 'react';
import BreedSelector from './BreedSelector'; // Import the BreedSelector component
import ImageGallery from './ImageGallery'; // Import the ImageGallery component
import './shared.css'; // Import the shared CSS file for common styles
import './app.css'; // Import the specific CSS file for the App component
import Borador from './Images/Borador.png'; // Correct import statement for the image

const App = () => {
  const [breed, setBreed] = useState(''); // State variable to hold the selected breed
  const [numImages, setNumImages] = useState(1); // State variable to hold the number of images to fetch
  const [images, setImages] = useState([]); // State variable to hold the fetched images, initialized as an empty array

  return (
    <div className="app"> {/* Main container for the application */}
      <img src={Borador} alt="Borador" className="header-image" /> {/* Display an image in the header */}
      <h1 className="header-title">Dog Image Gallery</h1> {/* Main title for the app */}
      <h3 className="header-subtitle">Browse images of your favorite dog breeds</h3> {/* Smaller header */}
      
      <div className="overlay-section"> {/* Container with overlay effect */}
        <BreedSelector 
          setBreed={setBreed} 
          setNumImages={setNumImages} 
          setImages={setImages}
        /> 
      </div>

      <ImageGallery 
        breed={breed} 
        numImages={numImages} 
        images={images} 
      /> 
    </div>
  );
};

export default App; // Export the App component as the default export
