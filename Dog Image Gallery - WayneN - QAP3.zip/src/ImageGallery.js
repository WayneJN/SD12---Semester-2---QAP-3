import React from 'react';
import './imageGallery.css';

const ImageGallery = ({ breed, numImages, images }) => {
  if (!Array.isArray(images)) {
    return <p>No images available.</p>; // Handle non-array images
  }

  return (
    <div className="image-gallery">
      <h2>{breed} Images</h2>
      <div className="images">
        {images.map((image, index) => (
          <img key={index} src={image} alt={`${breed} ${index + 1}`} className="dog-image" />
        ))}
      </div>
    </div>
  );
};

export default ImageGallery;
